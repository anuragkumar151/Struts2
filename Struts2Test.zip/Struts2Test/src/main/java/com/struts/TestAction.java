package com.struts;

public class TestAction {

	public String execute() {
		System.out.println("execute() called");
		return "Success";
	}
}
